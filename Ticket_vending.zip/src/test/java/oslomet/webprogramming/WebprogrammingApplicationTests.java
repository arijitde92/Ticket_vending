package oslomet.webprogramming;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebprogrammingApplicationTests {

    @Test
    void contextLoads() {
    }

}
